let minute = document.querySelector('#minutes')
let second = document.querySelector('#seconds')
const ok = document.querySelector('#ok')
const buttonStart = document.querySelector('#buttonStart')
const buttonStop = document.querySelector('#buttonStop')
const buttonReset = document.querySelector('#buttonReset')
const buttonOKMin = document.querySelector('#buttonOKMin')
const buttonOKSec = document.querySelector('#buttonOKSec')
const settingsButton = document.querySelector('#settings')
const settingsDisplay = document.querySelector('#settingsDisplay')
const inputMess = document.querySelector('#inputMess')
const url = document.querySelector('#url')
const fName = document.querySelector('#fontName')
const fSize = document.querySelector('#fontSizeInput')

const applyFontButton = document.querySelector('#applyFontButton')
const resetFontButton = document.querySelector('#resetFontButton')
const timerTextColor = document.querySelector('#timerTextColor')
const shadowColorDisplay = document.querySelector('#shadowColor')
const applyColor = document.querySelector('#applyColor')
const resetColor = document.querySelector('#resetColor')

const displayMess = document.querySelector('#displayMess')
const messButton = document.querySelector('#messButton')
const buttonUrl = document.querySelector('#buttonUrl')
const buttonFontName = document.querySelector('#buttonFontName')
const fontSettingsDisplay = document.querySelector('#fontSettingsDisplay')
const colorSettingsDisplay = document.querySelector('#colorSettingsDisplay')
const buttonFontMain = document.querySelector('#buttonFontMain')
const buttonColorMain = document.querySelector('#buttonColorMain')
const mainTab = document.querySelector('#mainTab')
const heightfont = parseInt(window.getComputedStyle(fontSettingsDisplay).getPropertyValue('height'))
const heightTab = parseInt(window.getComputedStyle(mainTab).getPropertyValue('height'))
const height = heightTab + heightfont
const lAlign = document.querySelector('#left')
const rAlign = document.querySelector('#right')
const cAlign = document.querySelector('#centre')
const tAlign = document.querySelector('#top')
const bAlign = document.querySelector('#bottom')
const mAlign = document.querySelector('#middle')
settingsDisplay.style.height = '0px'

let timer,
	countdown,
	messageAtZero = '',
	buttonPressed = 'none',
	zeroIsReached = false,
	settingsPresssed = false,
	messSubmitPressed = false,
	fontUrlPressed = false,
	fontNamePressed = false,
	fontUrl = '',
	fontName = '',
	fontSize = 0,
	fontApply = false,
	colorsApply = false,
	min = 0,
	sec = 0,
	sec2 = 0,
	mainTabPressed = 'font',
	hAlign = '',
	vAlign = '',
	textColor = '',
	shadowYN = true,
	shadowColor = '',
	storageInfo,
	tag = 'timerStorage:',
	alignText

// localStorage.removeItem('timerStorage:')
// console.log(rAlign)
// console.log(cAlign)
storageInfo = JSON.parse(window.localStorage.getItem('timerStorage:'))
// storageInfo [0]font Url,[1]font name,[2]fontSize,[3]message,[4]H align,[5]V align,[6]textColor,[7]shadowYN,[8]shadowColor
// console.log(storageInfo)
if (!storageInfo) defaultSettings()
else {
	updateSavedSettings()
}
const channelName = 'obsTimer'
const channel = new BroadcastChannel(channelName)
settingsButton.addEventListener('click', settings)

inputMess.value = messageAtZero
url.value = fontUrl
fName.value = fontName
fSize.value = fontSize
timerTextColor.value = textColor
shadowColorDisplay.value = shadowColor
// console.log(messSubmitPressed)
if (messSubmitPressed) messButton.textContent = 'SHOW'

setAlignPics()
setAlignIcon()
drawTime()

function hAlignButton(pos) {
	if (buttonPressed === 'start') {
		return
	}

	// console.log('hAlign ' + pos)
	if (pos === 1) {
		if (storageInfo[4] === 'left') return
		lAlign.src = alignText[2]
		cAlign.src = alignText[3]
		rAlign.src = alignText[5]
		storageInfo[4] = 'left'
		savestorage()
		drawTime()
	}
	if (pos === 2) {
		if (storageInfo[4] === 'center') return
		lAlign.src = alignText[1]
		cAlign.src = alignText[4]
		rAlign.src = alignText[5]
		storageInfo[4] = 'center'
		savestorage()
		drawTime()
	}
	if (pos === 3) {
		if (storageInfo[4] === 'right') return
		lAlign.src = alignText[1]
		cAlign.src = alignText[3]
		rAlign.src = alignText[6]
		storageInfo[4] = 'right'
		savestorage()
		drawTime()
	}
}

function vAlignButton(pos) {
	// console.log('vAlign ' + pos)
	if (buttonPressed === 'start') {
		return
	}

	console.log('hAlign ' + pos)
	if (pos === 1) {
		if (storageInfo[5] === 'flex-start') return
		tAlign.src = alignText[8]
		mAlign.src = alignText[9]
		bAlign.src = alignText[11]
		storageInfo[5] = 'flex-start'
		savestorage()
		drawTime()
	}
	if (pos === 2) {
		if (storageInfo[5] === 'center') return
		tAlign.src = alignText[7]
		mAlign.src = alignText[10]
		bAlign.src = alignText[11]
		storageInfo[5] = 'center'
		savestorage()
		drawTime()
	}
	if (pos === 3) {
		if (storageInfo[5] === 'flex-end') return
		tAlign.src = alignText[7]
		mAlign.src = alignText[9]
		bAlign.src = alignText[12]
		storageInfo[5] = 'flex-end'
		savestorage()
		drawTime()
	}
}
function savestorage() {
	localStorage.setItem('timerStorage:', JSON.stringify(storageInfo))
	let stor = JSON.parse(window.localStorage.getItem('timerStorage:'))
	// console.log(stor)
}
function setAlignIcon() {
	if (buttonPressed === 'start') {
		return
	}

	if (storageInfo[4] === 'left') {
		lAlign.src = alignText[2]
		cAlign.src = alignText[3]
		rAlign.src = alignText[5]
	}
	if (storageInfo[4] === 'center') {
		lAlign.src = alignText[1]
		cAlign.src = alignText[4]
		rAlign.src = alignText[5]
	}
	if (storageInfo[4] === 'right') {
		lAlign.src = alignText[1]
		cAlign.src = alignText[3]
		rAlign.src = alignText[6]
	}
	if (storageInfo[5] === 'flex-start') {
		tAlign.src = alignText[8]
		mAlign.src = alignText[9]
		bAlign.src = alignText[11]
	}
	if (storageInfo[5] === 'center') {
		tAlign.src = alignText[7]
		mAlign.src = alignText[10]
		bAlign.src = alignText[11]
	}
	if (storageInfo[5] === 'flex-end') {
		tAlign.src = alignText[7]
		mAlign.src = alignText[9]
		bAlign.src = alignText[12]
	}
}
function setAlignPics() {
	alignText = [
		'',
		'Images/leftGrey.png',
		'Images/leftWhite.png',
		'Images/centreGrey.png',
		'Images/centreWhite.png',
		'Images/rightGrey.png',
		'Images/rightWhite.png',
		'Images/topGrey.png',
		'Images/topWhite.png',
		'Images/middleGrey.png',
		'Images/middleWhite.png',
		'Images/bottomGrey.png',
		'Images/bottomWhite.png',
	]
}
function applyColors() {
	// console.log('Apply Colors Run')
	if (buttonPressed === 'start') {
		inputMin.value = ''
		return
	}
	textColor = timerTextColor.value
	storageInfo[6] = textColor
	shadowColor = shadowColorDisplay.value
	storageInfo[8] = shadowColor
	savestorage()
	drawTime()
}
function resetColors() {
	if (buttonPressed === 'start') {
		inputMin.value = ''
		return
	}
	textColor = '#ffffff'
	timerTextColor.value = textColor
	storageInfo[6] = textColor
	shadowColor = '#000000'
	shadowColorDisplay.value = shadowColor
	storageInfo[8] = shadowColor

	// console.log('Reset Color Run')
	savestorage()
	localStorage.setItem(tag, JSON.stringify(storageInfo))
	drawTime()
}

function applyFont() {
	if (buttonPressed === 'start') {
		inputMin.value = ''
		return
	}
	if (fSize.value <= 0 || fSize.value > 200) {
		fSize.value = 150
		fontSize = 150
	}
	// console.log('Apply Font Run')
	fontUrl = url.value
	fontName = fName.value
	fontSize = fSize.value

	storageInfo[0] = fontUrl
	storageInfo[1] = fontName
	storageInfo[2] = fontSize
	savestorage()
	drawTime()
}
function resetFont() {
	if (buttonPressed === 'start') {
		inputMin.value = ''
		return
	}

	// console.log('Reset Font Run')
	fontUrl = 'https://fonts.googleapis.com/css2?family=Nunito:wght@700&display=swap'
	fontName = 'Nunito'
	fontSize = 150
	storageInfo[0] = fontUrl
	storageInfo[1] = fontName
	storageInfo[2] = fontSize
	url.value = fontUrl
	fName.value = fontName
	fSize.value = fontSize
	savestorage()
	localStorage.setItem(tag, JSON.stringify(storageInfo))
	drawTime()
}
function defaultSettings() {
	// alert('defaultSettings run')
	fontUrl = 'https://fonts.googleapis.com/css2?family=Nunito:wght@700&display=swap'
	fontName = 'Nunito'
	fontSize = 150
	messageAtZero = ''
	hAlign = 'left'
	vAlign = 'flex-start'
	textColor = '#ffffff'
	shadowYN = true
	shadowColor = '#000000'
	storageInfo = [fontUrl, fontName, fontSize, messageAtZero, hAlign, vAlign, textColor, shadowYN, shadowColor] // [0]font Url,[1]font name,[2]fontSize,[3]message,[4]H align,[5]V align,[6]textColor,[7]shadowYN,[8]shadowColor

	localStorage.setItem(tag, JSON.stringify(storageInfo))
}
function updateSavedSettings() {
	// alert('UpdateSavedSettings run')
	fontUrl = storageInfo[0]
	fontName = storageInfo[1]
	fontSize = storageInfo[2]
	messageAtZero = storageInfo[3]
	if (storageInfo[3]) messSubmitPressed = true
	hAlign = storageInfo[4]
	vAlign = storageInfo[5]
	textColor = storageInfo[6]
	shadowYN = storageInfo[7]
	shadowColor = storageInfo[8]
}
function fontMain() {
	buttonFontMain.style.backgroundColor = 'rgb(90,0,0)'
	buttonColorMain.style.backgroundColor = 'rgb(31, 30, 31)'
	fontSettingsDisplay.style.display = 'block'
	colorSettingsDisplay.style.display = 'none'
}
function colorMain() {
	buttonFontMain.style.backgroundColor = 'rgb(31, 30, 31)'
	buttonColorMain.style.backgroundColor = 'rgb(90,0,0)'
	fontSettingsDisplay.style.display = 'none'
	colorSettingsDisplay.style.display = 'block'
}
function urlFunction() {
	if (url.value === '') {
		fontUrlPressed = false
		buttonUrl.textContent = 'SUBMIT'
		return
	} else {
		fontUrlPressed = true
		buttonUrl.textContent = 'SUBMITTED'
		fontUrl = url.value
	}
}
function fontNameFunction() {
	if (fName.value === '') {
		fontNamePressed = false
		buttonFontName.textContent = 'SUBMIT'
		return
	} else {
		fontNamePressed = true
		buttonFontName.textContent = 'SUBMITTED'
		fontName = fName.value
	}
}
function messBoxClicked() {
	messButton.textContent = 'SUBMIT'
	messSubmitPressed = false
}
function messSubmit() {
	if (!messSubmitPressed) {
		messSubmitPressed = true
		messButton.textContent = 'SHOW'
	} else {
		messSubmitPressed = false
		messButton.textContent = 'SUBMIT'
	}
	messageAtZero = inputMess.value
	storageInfo[3] = messageAtZero
	savestorage()
}
function settings() {
	if (mainTabPressed === 'font') fontMain()
	if (mainTabPressed === 'color') colorMain()
	if (settingsPresssed) settingsPresssed = false
	else settingsPresssed = true
	if (settingsPresssed) {
		let currHeight = 0
		let timer = setInterval(function () {
			settingsDisplay.style.height = currHeight + 'px'
			if (currHeight < height) currHeight += 4
			else clearInterval(timer)
		}, 1)
	} else {
		let currHeight = height
		let timer = setInterval(function () {
			settingsDisplay.style.height = currHeight + 'px'
			if (currHeight > 0) currHeight -= 4
			else clearInterval(timer)
		}, 1)
	}
}
function minutes() {
	if (buttonPressed === 'start') {
		inputMin.value = ''
		return
	}
	let minutes = document.getElementById('inputMin').value
	if (minutes < 0 || minutes > 59) inputMin.value = ''
	else {
		inputMin.value = ''
		min = minutes
		drawTime()
	}
}
function seconds() {
	if (buttonPressed === 'start') {
		inputSec.value = ''
		return
	}
	let seconds = document.getElementById('inputSec').value
	if (seconds < 0 || seconds > 59) inputSec.value = ''
	else {
		inputSec.value = ''
		sec = seconds
		drawTime()
	}
}
function startCountdown() {
	if (min <= 0 && sec <= 0) {
		zeroReached()
		return
	}
	if (min === 0) {
		sec -= 1
		drawTime()
		return
	}
	if (min > 0 && sec > 0) {
		sec -= 1
		drawTime()
		return
	}
	if (sec === 0) {
		sec = 59
		min -= 1
		drawTime()
		return
	}
}
function drawTime() {
	// console.log('drawTime')
	minute.innerHTML = min

	if (sec > 9) second.innerHTML = sec
	else {
		sec2 = '0' + sec.toString(10)
		second.innerHTML = sec2
	}
	// console.log(zeroIsReached)
	countdown = [min, sec, zeroIsReached, storageInfo]
	channel.postMessage(countdown)
}
function zeroReached() {
	// console.log('Zero Reached')
	zeroIsReached = true
	buttonPressed = 'none'
	countdown = [min, sec, zeroIsReached, storageInfo]
	localStorage.setItem(tag, JSON.stringify(storageInfo))
	channel.postMessage(countdown)
	zeroIsReached = false
	buttonStart.style.color = 'white'
	buttonStop.style.color = 'white'
	buttonReset.style.color = 'white'
	buttonOKMin.style.color = 'white'
	buttonOKSec.style.color = 'white'
	applyFontButton.style.color = 'white'
	resetFontButton.style.color = 'white'
	applyColor.style.color = 'white'
	resetColor.style.color = 'white'
	setAlignIcon()
	clearInterval(timer)
}
function startButton() {
	buttonPressed = 'start'
	buttonStart.style.color = 'red'
	buttonStop.style.color = 'white'
	buttonReset.style.color = 'rgba(255, 255, 255, 0.2)'
	buttonOKMin.style.color = 'rgba(255, 255, 255, 0.2)'
	buttonOKSec.style.color = 'rgba(255, 255, 255, 0.2)'
	applyFontButton.style.color = 'rgba(255, 255, 255, 0.2)'
	resetFontButton.style.color = 'rgba(255, 255, 255, 0.2)'
	applyColor.style.color = 'rgba(255, 255, 255, 0.2)'
	resetColor.style.color = 'rgba(255, 255, 255, 0.2)'
	lAlign.src = alignText[1]
	cAlign.src = alignText[3]
	rAlign.src = alignText[5]
	tAlign.src = alignText[7]
	mAlign.src = alignText[9]
	bAlign.src = alignText[11]
	timer = setInterval(startCountdown, 1000)
}
function stopButton() {
	buttonPressed = 'stop'
	buttonStart.style.color = 'white'
	buttonStop.style.color = 'red'
	buttonReset.style.color = 'white'
	buttonOKMin.style.color = 'white'
	buttonOKSec.style.color = 'white'
	applyFontButton.style.color = 'white'
	resetFontButton.style.color = 'white'
	applyColor.style.color = 'white'
	resetColor.style.color = 'white'
	messSubmit.value = storageInfo[3]
	url.value = storageInfo[0]
	fName.value = storageInfo[1]
	fSize.value = storageInfo[2]
	timerTextColor.value = storageInfo[6]
	shadowColorDisplay.value = storageInfo[8]
	setAlignIcon()
	clearInterval(timer)
}
function resetButton() {
	if (buttonPressed === 'start') return
	zeroIsReached = false
	buttonPressed = 'reset'
	clearInterval(timer)
	buttonStart.style.color = 'white'
	buttonStop.style.color = 'white'
	buttonReset.style.color = 'white'
	buttonOKMin.style.color = 'white'
	buttonOKSec.style.color = 'white'
	min = 0
	sec = 0
	inputMin.value = ''
	inputSec.value = ''
	drawTime()
}
