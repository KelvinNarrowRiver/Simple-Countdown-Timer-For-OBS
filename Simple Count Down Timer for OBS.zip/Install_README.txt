A Simple Countdown Timer for starting a live stream with minutes and seconds
With a Dock and Browser Source for use in OBS
Simple to install and use

Download - Simple Count Down Timer for OBS.zip


Instalation:

Unzip -  Simple Count Down Timer for OBS.zip  -  to a folder of your choosing
Open OBS

Dock:

Add the dock by clicking on Dock/Custom Browser Docks and in the Panel that opens 
Add a Dock Name (This can be of your choosing)
Add the URL by clicking on Dock.html (from the folder you unziped the files to) and adding the URL link from the Browser that opens
Click Apply and dock is added
Place Dock window wherever you wish

Browser:

Add the Browser Source by clicking on the Plus icon in sources and in the Panel that opens
Click on Browser
In Create New add a name of your choosing and click OK and the Propeties Panel opens
Add the URL by clicking on Browser.html (from the folder you unziped the files to) and adding the URL link from the Browser that opens 
Add Width and Height of your choosing - 1920x1080 is commonly used
Change other setting as you wish then click OK
Adjust window to wherever you wish Timer and Messsage to display


Congratulations the Dock and Bowser are added - enjoy

